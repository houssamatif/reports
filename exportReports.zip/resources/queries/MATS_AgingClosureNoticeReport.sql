SELECT DISTINCT
    a.issue_id,
    a.apl_num,
    a.co_req_seq,
    a.generate_dt,
    ( trunc(SYSDATE - a.generate_dt + 1, 0) ) AS "Age (Days)",
    (
        CASE
            WHEN fi.issue_type_cd = 'MC'   THEN
                'MCC Change'
            WHEN fi.issue_type_cd = 'RB'   THEN
                'Reimbursement and Billing'
            WHEN fi.issue_type_cd = 'VF'   THEN
                'Valid Factual Dispute'
            WHEN fi.issue_type_cd = 'PA'   THEN
                'Prior Authorization Additional Time'
            WHEN fi.issue_type_cd = 'MR'   THEN
                'More Information Request'
            WHEN fi.issue_type_cd = 'PP'   THEN
                'Peer to Peer'
            WHEN fi.issue_type_cd = 'RE'   THEN
                'Referral'
            WHEN fi.issue_type_cd = 'TL'   THEN
                'T21 / Legacy'
            WHEN fi.issue_type_cd = 'MS'   THEN
                'Missed Shift'
        END
    ) AS "Issue Type",
    (
        CASE
            WHEN fi.area_of_law_cd = 'PH'   THEN
                'Pharmacy'
            WHEN fi.area_of_law_cd = 'DE'   THEN
                'Dental'
            WHEN fi.area_of_law_cd = 'MC'   THEN
                'Medical Services and Care'
            WHEN fi.area_of_law_cd = 'PA'   THEN
                'Prior Authorization Lock-In'
            WHEN fi.area_of_law_cd = 'PL'   THEN
                'Pharmacy Lock-In'
        END
    ) AS "Area of Law",
    me.first_name
    || ' '
    || me.last_name AS "Generate User",
    (
        CASE
            WHEN fts.emp_id = 0
                 OR fts.emp_id IS NULL THEN
                'unassigned'
            ELSE
                (
                    SELECT DISTINCT
                        me.first_name
                        || ' '
                        || me.last_name AS "Generate User"
                    FROM
                        ie_app_online.mo_employees me
                    WHERE
                        me.emp_id = fts.emp_id
                )
        END
    ) AS "Task Assignee"
FROM
    ie_app_online.co_request_history   a
    INNER JOIN ie_app_online.mo_employees         me ON me.user_id = a.create_user_id
    INNER JOIN ie_app_online.fh_issue             fi ON fi.issue_id = a.issue_id
    INNER JOIN ie_app_online.fh_doc               fd ON fd.issue_id = a.issue_id
    INNER JOIN ie_app_online.fh_task_status       fts ON fts.doc_seq_num = fd.doc_seq_num
WHERE
    a.doc_id = 'NGG803'
    AND a.pending_trig_sw = 'B'
    AND a.co_status_sw NOT IN (
        'S',
        'F',
        'B'
    )
    AND trunc(a.generate_dt) NOT IN (
        trunc(SYSDATE)
    )
    AND ( SYSDATE - a.generate_dt + 1 ) >= 5
    AND fd.doc_ref_id = 600000176
    AND fts.task_status_cd IN (
        'NS',
        'IP'
    )
    AND fts.eff_end_tms IS NULL