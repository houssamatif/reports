SELECT H.CO_REQ_SEQ, 
H.DOC_ID, X.DOC_NAME, H.LANGUAGE_CD, H.ISSUE_ID , H.MATS_APL_NUM,

CASE 
    WHEN  F.ISSUE_TYPE_CD = 'TL' THEN 'T21 / Legacy' 
    WHEN  F.ISSUE_TYPE_CD = 'RB' THEN 'Reimbursement and Billing' 
    WHEN  F.ISSUE_TYPE_CD = 'RE' THEN 'Referral' 
    WHEN  F.ISSUE_TYPE_CD = 'MR' THEN 'More Information Request' 
    WHEN  F.ISSUE_TYPE_CD = 'VF' THEN 'Valid Factual Dispute' 
    WHEN  F.ISSUE_TYPE_CD = 'MC' THEN 'MCC Change' 
    WHEN  F.ISSUE_TYPE_CD = 'MS' THEN 'Missed Shift' 
    WHEN  F.ISSUE_TYPE_CD = 'PA' THEN 'Prior Authorization Additional Time' 
    WHEN  F.ISSUE_TYPE_CD = 'PP' THEN 'Peer to Peer' 
ELSE 'Unknown' END AS ISSUE_TYPE, 
CASE
    WHEN  F.AREA_OF_LAW_CD = 'DE' THEN 'Dental' 
    WHEN  F.AREA_OF_LAW_CD = 'MC' THEN 'Medical Services and Care' 
    WHEN  F.AREA_OF_LAW_CD = 'PH' THEN 'Pharmacy' 
ELSE ' ' END AS AREA_OF_LAW, 
H.CREATE_USER_ID, H.MISC_PARMS, h.special_notes
FROM  IE_APP_ONLINE.CO_REQUEST_HISTORY H INNER JOIN IE_APP_ONLINE.FH_ISSUE F ON F.ISSUE_ID = H.ISSUE_ID
LEFT OUTER JOIN IE_APP_ONLINE.CO_REQUEST_HISTORY_DETAIL D 
ON H.CO_REQ_SEQ = D.CO_REQ_SEQ 
INNER JOIN IE_APP_ONLINE.CO_MASTER X ON X.DOC_ID = H.DOC_ID
WHERE TRUNC(D.PRINT_DT) =  
(CASE
                    WHEN mod(TO_CHAR((SYSDATE - 1), 'J'), 7) + 1 = 7 THEN
                       TO_CHAR(SYSDATE - 3)
                    ELSE
                       TO_CHAR(SYSDATE - 1)
            END  )

and H.REQUEST_TYPE_CD IN ('M', 'I') 
AND CO_STATUS_SW not in ('S', 'F', 'K') AND DRAFT_SW = 'N' AND PENDING_TRIG_SW ='N' 